#!/system/bin/sh

# unload modules

  rmmod cifs
  rmmod md4
  rmmod nfsv4
  rmmod nfsv3
  rmmod nfsv2
  rmmod nfs
  rmmod auth_rpcgss
  rmmod oid_registry
  rmmod lockd
  rmmod grace
  rmmod dns_resolver
  rmmod sunrpc
