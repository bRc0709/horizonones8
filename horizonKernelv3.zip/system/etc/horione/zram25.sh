#!/system/bin/sh

TOTAL_RAM_MB=3711
NR_CPUS=8
RAM_PERCENT=25

# reset zram if it's already running
	/system/etc/horione/zram0.sh

# enable zram

# enable wakelock
	echo zram25 > /sys/power/wake_lock

# load modules
	insmod /system/lib/modules/zsmalloc.ko
	insmod /system/lib/modules/lz4_compress.ko
	insmod /system/lib/modules/lz4_decompress.ko
	insmod /system/lib/modules/zram.ko num_devices=$NR_CPUS

# initialize the devices
	SIZE=$((TOTAL_RAM_MB * RAM_PERCENT / NR_CPUS / 100))
	for i in $(seq 0 "$((NR_CPUS - 1))")
	do
		echo "$((SIZE))M" > /sys/block/zram$i/disksize
		mkswap /dev/block/zram$i
		swapon -p 5 /dev/block/zram$i
	done

# disable wakelock
	echo zram25 > /sys/power/wake_unlock
