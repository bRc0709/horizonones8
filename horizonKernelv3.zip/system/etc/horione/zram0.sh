#!/system/bin/sh

NR_CPUS=8

# reset zram if it's already running
	ZRAM0=/sys/block/zram0
	ZRAM1=/sys/block/zram1
	ZRAM2=/sys/block/zram2
	ZRAM3=/sys/block/zram3
	ZRAM4=/sys/block/zram4
	ZRAM5=/sys/block/zram5
	ZRAM6=/sys/block/zram6
	ZRAM7=/sys/block/zram7
	if [ -d $ZRAM0 ] || [ -d $ZRAM1 ] || [ -d $ZRAM2 ] || [ -d $ZRAM3 ] || [ -d $ZRAM4 ] || [ -d $ZRAM5 ] || [ -d $ZRAM6 ] || [ -d $ZRAM7 ] ; then

		# disable zram

		# enable wakelock
			echo zram0 > /sys/power/wake_lock
   
		# swapoff
			swapoff /dev/block/zram0 & \
			swapoff /dev/block/zram1 & \
			swapoff /dev/block/zram2 & \
			swapoff /dev/block/zram3 & \
			swapoff /dev/block/zram4 & \
			swapoff /dev/block/zram5 & \
			swapoff /dev/block/zram6 & \
			swapoff /dev/block/zram7 & \
			wait
			sleep 1

		# reset devices
			for i in $(seq 0 "$((NR_CPUS - 1))")
			do
				echo 1 > /sys/block/zram$i/reset
			done

		# unload modules
			rmmod zram
			rmmod lz4_decompress
			rmmod lz4_compress
			rmmod zsmalloc

		# disable wakelock
			echo zram0 > /sys/power/wake_unlock

	fi
