#!/system/bin/sh

# export last_kmsg to the emulated sdcard

cp /proc/last_kmsg /storage/emulated/0/last_kmsg.txt