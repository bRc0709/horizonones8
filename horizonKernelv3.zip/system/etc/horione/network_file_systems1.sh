#!/system/bin/sh

  # load modules

  insmod /system/lib/modules/sunrpc.ko
  insmod /system/lib/modules/dns_resolver.ko
  insmod /system/lib/modules/grace.ko
  insmod /system/lib/modules/lockd.ko
  insmod /system/lib/modules/oid_registry.ko
  insmod /system/lib/modules/auth_rpcgss.ko
  insmod /system/lib/modules/nfs.ko
  insmod /system/lib/modules/nfsv2.ko
  insmod /system/lib/modules/nfsv3.ko
  insmod /system/lib/modules/nfsv4.ko
  insmod /system/lib/modules/md4.ko
  insmod /system/lib/modules/cifs.ko
