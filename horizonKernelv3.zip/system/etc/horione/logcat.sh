#!/system/bin/sh

# export dmesg and logcat to the emulated sdcard

logcat -d > /storage/emulated/0/logcat.txt

dmesg > /storage/emulated/0/dmesg.txt